APLIKASI VIDEO LOOP

Fitur:
- Saat aplikasi dibuka, video langsung diputar.
- Video berulang otomatis (loop).
- Audio asli dari video tetap aktif.
- Tampilan layar penuh, orientasi mendatar.

Cara build:
1. Ekstrak ZIP ini.
2. Buka folder VideoLoopApp sebagai proyek di AndroidIDE atau Android Studio.
3. Tunggu Gradle selesai sinkronisasi.
4. Pilih Build > Build APK(s).
5. Pasang APK hasil build di HP.

Catatan:
- Video sudah disertakan di app/src/main/res/raw/loop_video.mp4.
- Nama aplikasi saat ini: Video Loop.
